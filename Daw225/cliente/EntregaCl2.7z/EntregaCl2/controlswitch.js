let mensaje = "Introduce la inicial del dia de la semana";
let Inicial = prompt(mensaje);
switch (Inicial) {
    case "L":
        
        break;
        
    case "M":
        console.log("Martes");
        break;
    case "X":
        console.log("Miercoles");
        break;
    case "J":
        console.log("Jueves");
        break;
    case "V":
        console.log("Viernes");
        break;
    case "S":
        console.log("Sabado");
        break;
    case "D":
        console.log("Domingo");
        break;
    default:
        console.log("Inicial no valida");
}

    

