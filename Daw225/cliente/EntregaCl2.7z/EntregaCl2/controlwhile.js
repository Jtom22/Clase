let letra ='';
while (letra != 's') {
    let mensaje = "Introduce una letra";
    letra = prompt(mensaje);
    
}
alert("Gracias por poner la s");