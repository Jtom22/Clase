alert(" No eligas la tercera, es muy mala idea");
subcadena_1="Vaya";
subcadena_2="Playa"
subcadena_3="Yaya "
cadenaFinal=`Cadena:${subcadena_1}${subcadena_2}${subcadena_3}`;
document.write(cadenaFinal);
