
//Mostrar nombre y decision
let mensaje = "Introduce tu nombre";
let respuesta = prompt(mensaje);
let mensaje2 = "Estas seguro de quieres abandonar?";
let respuesta2 = confirm(mensaje2);
alert(`La decision del usuario es: ${respuesta2}`);

//Tipo de salida
//La primera será tipo String
//La segunda será tipo boolean
//Y la tercera de tipo string porque incluimos el resultado del boolean en un string.

